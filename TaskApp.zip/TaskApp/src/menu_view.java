package TaskApp;

 class menu_view {
	 
		
		protected static void menu_view() {
			 System.out.println("Task List Application");
		        System.out.println("1. Add Task");
		        System.out.println("2. Remove Task");
		        System.out.println("3. List Tasks");
		        System.out.println("4. Quit");
		        System.out.print("Select an option:- ");
		 }
		 
	}


